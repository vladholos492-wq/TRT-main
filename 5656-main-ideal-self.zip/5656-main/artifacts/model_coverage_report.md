# Model Coverage Report

Generated: 2025-12-23T17:27:51.748054

## Summary

| Metric | Value |
|--------|-------|
| Registry models | 107 |
| UI models | 89 |
| Coverage | 83.18% |
| Missing in UI | 18 |
| Extra in UI | 0 |
| Broken schemas | 0 |

## Status

### ❌ Missing in UI (18)

- `AI_INTEGRATION_IMPROVEMENTS` - no pricing
- `ARCHITECTURE` - no pricing
- `FLOWS` - no pricing
- `KLING_V2_1_STANDARD_INTEGRATION` - no pricing
- `MODELS_AND_PRICING_RU` - no pricing
- `OFFICIAL_API_DOCUMENTATION_INDEX` - no pricing
- `PLAN` - no pricing
- `RENDER` - no pricing
- `RISK_REGISTER` - no pricing
- `STATE` - no pricing
- `STRICT_INTEGRATION_RULES` - no pricing
- `all_models_test_results` - no pricing
- `cheap_models_test_results` - no pricing
- `generation_test_results_20251217_170008` - no pricing
- `generation_test_results_20251217_170332` - no pricing
- `image_processor` - no pricing
- `text_processor` - no pricing
- `url_processor` - no pricing

### ✅ No extra models

### ✅ All schemas valid

